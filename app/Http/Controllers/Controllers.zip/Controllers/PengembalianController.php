<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Spipu\Html2Pdf\Html2Pdf;


date_default_timezone_set('Asia/Jakarta');
class PengembalianController extends Controller
{
    //
    public function pengembalian(){
    	$cari = 0;
    	$pinjam = DB::table('pinjam')
    	->join('buku','pinjam.kd_buku', '=', 'buku.kd_buku')
    	->join('member','pinjam.kd_member','=', 'member.kd_member')
    	->select('pinjam.*', 'buku.*', 'member.*')->where('member.kd_member',$cari)
    	->get();

        $member = DB::table('member')->where('is_delete','N')->get();

    	$db = DB::table('pinjam')
    	->join('buku','pinjam.kd_buku', '=', 'buku.kd_buku')
    	->join('member','pinjam.kd_member','=', 'member.kd_member')
    	->select('pinjam.*', 'buku.*', 'member.*')->where('pinjam.status',2)
    	->get();
    	//return $db;
    	return view('pengembalian.pengembalian',['data_pinjam' => $db, 'data_peminjam' => $pinjam ,'member'=>$member]);
    }
   
    public function caripengembalian(Request $request){
    	$cari = $request->cari;
    	$pinjam = DB::table('pinjam')
    	->join('buku','pinjam.kd_buku', '=', 'buku.kd_buku')
    	->join('member','pinjam.kd_member','=', 'member.kd_member')
    	->select('pinjam.*', 'buku.*', 'member.*')->where('pinjam.status',2)
    	->get();

        $member = DB::table('member')->where('is_delete','N')->get();

    	$db = DB::table('pinjam')
    	->join('buku','pinjam.kd_buku', '=', 'buku.kd_buku')
    	->join('member','pinjam.kd_member','=', 'member.kd_member')
    	->select('pinjam.*', 'buku.*', 'member.*')->where('member.kd_member',$cari)->where('pinjam.status',2)
    	->get();
    	return view('pengembalian.pengembalian',['data_peminjam' => $db, 'data_pinjam' => $pinjam,'member' => $member]);
    }
    public function updatepengembalian(Request $request){
		
		$kd_member = $request->kd_member;

    	DB::table('pinjam')->where('kd_member',$kd_member)->where('status',2)->update([
    		'status' => 3,
            'keterangan' => 'Dikembalikan'
    	]);
        DB::table('pengembalian')->insert([
            'kd_pinjam' => $request->kd_pinjam,
			'tgl_pengembalian' => $request->tgl_kembali,
			'created_by' => $request->kd_admin,
			'created_date' => date('Y-m-d H:i:s')
        ]);
    	return redirect('/pengembalian-buku');
    }
    public function ReportPengembalianBuku(){
          $Html2Pdf = new Html2Pdf('P','A4','en');
        $db = DB::table('pinjam')
        ->join('buku','pinjam.kd_buku','=', 'buku.kd_buku')
        ->join('member','pinjam.kd_member','=', 'member.kd_member')
        ->join('pengembalian','pinjam.kd_pinjam', '=', 'pengembalian.kd_pinjam')
        ->select('pinjam.*','buku.*','member.*','pengembalian.*')->where('pinjam.status',2)->get();
        $Html2Pdf->pdf->setTitle('Laporan Pengembalian');
        $Html2Pdf->writeHTML(view('laporan-pengembalian.Laporan-Pengembalian',['pinjam' => $db]));
        $Html2Pdf->output('Laporan-Pengembalian.pdf');
    }
}
