<?php

namespace App\Http\Controllers\Laporan;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Spipu\Html2Pdf\Html2Pdf;
use Maatwebsite\Excel\Facades\Excel;

class laporanPengembalianController extends Controller
{
    //
    public function view_laporan_pengembalian(){
        $pengembalian = DB::table('pinjam')
        ->join('buku','pinjam.kd_buku','=','buku.kd_buku')
        ->join('member','pinjam.kd_member','=','member.kd_member')
        ->join('pengembalian','pinjam.kd_pinjam','=','pengembalian.kd_pinjam')
        ->select('pinjam.*','buku.*','member.*','pengembalian.*')->where('pinjam.status',3)->get();
        return view('laporan-pengembalian.Laporan-Pengembalian',['pengembalian' => $pengembalian]);
    }
    public function print_laporan_berdasarkan_tgl_excel(){
      
        Excel::create('Laporan Pengembalian Buku', function($excel){
            $excel -> setTitle('Export to Excel');
            $excel -> setCreator('Effendy Wahyu')
                   -> setCompany('PT CN Plus');
            $excel ->sheet('Laporan Pengembalian Buku', function($sheet){
                $sheet->mergeCells('A1:W1');
                $sheet->row(1, function($row){
                    $row->setFontFamily('Arial');
                    $row->setFontSize(14);
                });
                $sheet->row(1, array('Data Pengembalian Buku'));
                $sheet->row(2, function($row){
                    $row->setFontFamily('Arial');
                    $row->setFontSize(10);
                    $row->setFontWeight('bold');
                });

                $sheet->row(2, array('Laporan Data Pengembalian Buku'));
                
                $tgl_dari = $_REQUEST['tgl_dari'];
                $tgl_sampai = $_REQUEST['tgl_sampai'];
        
                $pengembalian = DB::table('pinjam')
                ->join('buku','pinjam.kd_buku','=','buku.kd_buku')
                ->join('member','pinjam.kd_member','=','member.kd_member')
                ->join('pengembalian','pinjam.kd_pinjam','=','pengembalian.kd_pinjam')
                ->select('pinjam.*','buku.*','member.*','pengembalian.*')->where('pinjam.status',3)
                ->whereBetween('tgl_pengembalian',[$tgl_dari,$tgl_sampai])->get();
        
                $column = array('No','Nama','Judul Buku','Tanggal Pinjam','Tanggal Kembali', 'Tanggal Pengembalian');
                $sheet->appendRow($column);

                $sheet->row($sheet -> getHighestRow(), function ($row){
                    $row->setFontWeight('bold');
                });

                $no = 0;
                foreach($pengembalian as $pb){ 
                $no++;
                $sheet->appendRow(array($no,
                $pb -> nama_member,
                $pb -> judul_buku,
                $pb -> tgl_pinjam,
                $pb -> tgl_kembali,
                $pb -> tgl_pengembalian
                ));
                }
            });
        })->export('xls');
    }
    public function print_laporan_berdasarkan_tgl_pdf(){
        $Html2Pdf = new Html2Pdf('P','A4','en');
        
        $tgl_dari = $_REQUEST['tgl_dari'];
        $tgl_sampai = $_REQUEST['tgl_sampai'];

        $pengembalian = DB::table('pinjam')
        ->join('buku','pinjam.kd_buku','=','buku.kd_buku')
        ->join('member','pinjam.kd_member','=','member.kd_member')
        ->join('pengembalian','pinjam.kd_pinjam','=','pengembalian.kd_pinjam')
        ->select('pinjam.*','buku.*','member.*','pengembalian.*')->where('pinjam.status',3)->whereBetween('pengembalian.tgl_pengembalian',[$tgl_dari,$tgl_sampai])->get();
        $Html2Pdf->pdf->setTitle('Laporan Pengembalian Buku');
        $Html2Pdf->writeHTML(view('laporan-pengembalian.Print-Laporan-Pengembalian',['pengembalian' => $pengembalian]));
        $Html2Pdf->output('Laporan Pengembalian Buku.pdf');
   
    }
    public function print_laporan_pengembalian_pdf(){
        $Html2Pdf = new Html2Pdf('P','A4','en');
        $pengembalian = DB::table('pinjam')
        ->join('buku','pinjam.kd_buku','=','buku.kd_buku')
        ->join('member','pinjam.kd_member','=','member.kd_member')
        ->join('pengembalian','pinjam.kd_pinjam','=','pengembalian.kd_pinjam')
        ->select('pinjam.*','buku.*','member.*','pengembalian.*')->where('pinjam.status',3)->get();
        $Html2Pdf->pdf->setTitle('Laporan Pengembalian Buku');
        $Html2Pdf->writeHTML(view('laporan-pengembalian.Print-Laporan-Pengembalian',['pengembalian' => $pengembalian]));
        $Html2Pdf->output('Laporan Pengembalian Buku.pdf');
    }
    function print_laporan_pengembalian_excel(){        
        Excel::create('Laporan Pengembalian Buku', function($excel){
            $excel -> setTitle('Export to Excel');
            $excel -> setCreator('Effendy Wahyu')
                   -> setCompany('PT CN Plus');
            $excel ->sheet('Laporan Pengembalian Buku', function($sheet){
                $sheet->mergeCells('A1:W1');
                $sheet->row(1, function($row){
                    $row->setFontFamily('Arial');
                    $row->setFontSize(14);
                });
                $sheet->row(1, array('Data Pengembalian Buku'));
                $sheet->row(2, function($row){
                    $row->setFontFamily('Arial');
                    $row->setFontSize(10);
                    $row->setFontWeight('bold');
                });

                $sheet->row(2, array('Laporan Data Pengembalian Buku'));
               
                $pengembalian = DB::table('pinjam')
                ->join('buku','pinjam.kd_buku','=','buku.kd_buku')
                ->join('member','pinjam.kd_member','=','member.kd_member')
                ->join('pengembalian','pinjam.kd_pinjam','=','pengembalian.kd_pinjam')
                ->select('pinjam.*','buku.*','member.*','pengembalian.*')->where('pinjam.status',3)->get();
        
                $column = array('No','Nama','Judul Buku','Tanggal Pinjam','Tanggal Kembali', 'Tanggal Pengembalian');
                $sheet->appendRow($column);

                $sheet->row($sheet -> getHighestRow(), function ($row){
                    $row->setFontWeight('bold');
                });

                $no = 0;
                foreach($pengembalian as $pb){ 
                $no++;
                $sheet->appendRow(array($no,
                $pb -> nama_member,
                $pb -> judul_buku,
                $pb -> tgl_pinjam,
                $pb -> tgl_kembali,
                $pb -> tgl_pengembalian
                ));
                }
            });
        })->export('xls');
    }
}
