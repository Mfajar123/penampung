<?php
namespace App\Http\Controllers\Laporan;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Spipu\Html2Pdf\Html2Pdf;
use Maatwebsite\Excel\Facades\Excel;

class laporanBukuController extends Controller
{
    //
    function view_laporan_buku(){
        $lap_buku = DB::table('buku')->where('is_delete','N')->get();
        return view('laporan-buku.data_laporan_buku',['lap_buku' => $lap_buku]);
    }
    function print_laporan_buku_pdf(){
        $Html2Pdf = new Html2Pdf('P','A4','en');
        $buku = DB::table('buku')->where('is_delete','N')->get();
        $Html2Pdf->pdf->SetTitle('Laporan Buku');
        $Html2Pdf->writeHTML(view('laporan-buku.Laporan-Buku',['buku'=>$buku]));
        $Html2Pdf->output('daftar-buku.pdf');
    }
    function print_laporan_buku_excel(){
        Excel::create('Laporan-Buku', function($excel) {
            // Set the title
            $excel->setTitle('Expot to Excel');
            // Chain the setters
            $excel->setCreator('Effendy')
                  ->setCompany('PT CN Plus');
            // Call them separately
            $excel->sheet('Laporan Buku', function ($sheet) {
   
            // first row styling and writing content
            $sheet->mergeCells('A1:W1');
            $sheet->row(1, function ($row) {
                $row->setFontFamily('Comic Sans MS');
                $row->setFontSize(20);
            });
   
            $sheet->row(1, array('Daftar Buku'));
   
            // second row styling and writing content
            $sheet->row(2, function ($row) {
   
                // call cell manipulation methods
                $row->setFontFamily('Comic Sans MS');
                $row->setFontSize(10);
                $row->setFontWeight('bold');
   
            });
              $sheet->row(2, array('Laporan Daftar Buku'));
              $customers = DB::table('buku')->where('is_delete','N')->get();
   
              $column = array('Judul Buku', 'Jumlah Buku','Penulis','Penerbit','Tahun Terbit');
   
              $sheet->appendRow($column);
   
              // getting last row number (the one we already filled and setting it to bold
              $sheet->row($sheet->getHighestRow(), function ($row) {
                  $row->setFontWeight('bold');
              });
   
              // putting customers data as next rows
              foreach ($customers as $customer) {
                  $sheet->appendRow(array($customer->judul_buku,$customer->jumlah_buku,$customer->penulis,$customer->penerbit,$customer->tahun_terbit));
              }
            });
   
          })->export('xls');
    }
    function print_laporan_buku_berdasarkan_tgl_pdf(){
        $tgl_dari = $_REQUEST['tgl_dari'];
        $tgl_sampai = $_REQUEST['tgl_sampai'];
        $Html2Pdf = new Html2Pdf('P','A4','en');
        $buku = DB::table('buku')->whereBetween('date_input',[$tgl_dari,$tgl_sampai])->where('is_delete','N')->get();
        $Html2Pdf->pdf->SetTitle('Laporan Buku');
        $Html2Pdf->writeHTML(view('laporan-buku.Laporan-Buku',['buku'=>$buku]));
        $Html2Pdf->output('daftar-buku.pdf');

    }
    function print_laporan_buku_berdasarkan_tgl_excel(){
        Excel::create('Laporan-Buku', function($excel) {
          // Set the title
          $excel->setTitle('Expot to Excel');
          // Chain the setters
          $excel->setCreator('Effendy')
                ->setCompany('PT CN Plus');
          // Call them separately
          $excel->sheet('Laporan Buku', function ($sheet) {
 
          // first row styling and writing content
          $sheet->mergeCells('A1:W1');
          $sheet->row(1, function ($row) {
              $row->setFontFamily('Comic Sans MS');
              $row->setFontSize(20);
          });
 
          $sheet->row(1, array('Daftar Buku'));
 
          // second row styling and writing content
          $sheet->row(2, function ($row) {
 
              // call cell manipulation methods
              $row->setFontFamily('Comic Sans MS');
              $row->setFontSize(10);
              $row->setFontWeight('bold');
 
          });
          $tgl_dari = $_REQUEST['tgl_dari'];
          $tgl_sampai = $_REQUEST['tgl_sampai'];

            $sheet->row(2, array('Laporan Daftar Buku'));
            $customers = DB::table('buku')->whereBetween('date_input',[$tgl_dari,$tgl_sampai])->where('is_delete','N')->get();
 
            $column = array('Judul Buku', 'Jumlah Buku','Penulis','Penerbit','Tahun Terbit');
 
            $sheet->appendRow($column);
 
            // getting last row number (the one we already filled and setting it to bold
            $sheet->row($sheet->getHighestRow(), function ($row) {
                $row->setFontWeight('bold');
            });
 
            // putting customers data as next rows
            foreach ($customers as $customer) {
                $sheet->appendRow(array($customer->judul_buku,$customer->jumlah_buku,$customer->penulis,$customer->penerbit,$customer->tahun_terbit));
            }
          });
 
        })->export('xls');
    }
}
