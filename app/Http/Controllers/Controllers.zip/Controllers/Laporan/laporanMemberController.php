<?php

namespace App\Http\Controllers\Laporan;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Spipu\Html2Pdf\Html2Pdf;
use Maatwebsite\Excel\Facades\Excel;

class laporanMemberController extends Controller
{
    //
    function view_laporan_member(){
        $db = DB::table('member')->get();
        return view('laporan-member.Laporan-Member',['member' => $db]);
    }
    function print_laporan_member_pdf(){
        $Html2Pdf = new Html2Pdf('P','A4','en');
        $member = DB::table('member')->where('is_delete','N')->get();
        $Html2Pdf->pdf->setTitle('Laporan Member');
        $Html2Pdf->writeHTML(view('laporan-member.Print-Laporan-Member',['member' => $member]));
		$Html2Pdf->output('Laporan-Member.pdf');
    }
    function print_laporan_member_berdasarkan_tgl_pdf(){
        $tgl_dari = $_REQUEST['tgl_dari'];
        $tgl_sampai = $_REQUEST['tgl_sampai'];

        $Html2Pdf = new Html2Pdf('P','A4','en');
        $member = DB::table('member')->where('is_delete','N')->whereBetween('date_input',[$tgl_dari,$tgl_sampai])->get();
        $Html2Pdf->pdf->setTitle('Laporan Member');
        $Html2Pdf->writeHTML(view('laporan-member.Print-Laporan-Member',['member' => $member]));
		$Html2Pdf->output('Laporan-Member.pdf');
    }
    function print_laporan_member_excel(){
        Excel::create('Laporan-Member', function($excel) {
            // Set the title
            $excel->setTitle('Expot to Excel');
            // Chain the setters
            $excel->setCreator('Effendy')
                  ->setCompany('PT CN Plus');
            // Call them separately
            $excel->sheet('Laporan Member', function ($sheet) {
   
            // first row styling and writing content
            $sheet->mergeCells('A1:W1');
            $sheet->row(1, function ($row) {
                $row->setFontFamily('Comic Sans MS');
                $row->setFontSize(15);
            });
   
            $sheet->row(1, array('Daftar Member'));
   
            // second row styling and writing content
            $sheet->row(2, function ($row) {
   
                // call cell manipulation methods
                $row->setFontFamily('Comic Sans MS');
                $row->setFontSize(10);
                $row->setFontWeight('bold');
   
            });
            
                $sheet->row(2, array('Laporan Daftar Member'));
              $member= DB::table('member')->where('is_delete','N')->get();
   
              $column = array('Nama Member', 'Alamat Member','Tempat Lahir','Tanggal Lahir','Jenis Kelamin','No Hp');
   
              $sheet->appendRow($column);
   
              // getting last row number (the one we already filled and setting it to bold
              $sheet->row($sheet->getHighestRow(), function ($row) {
                  $row->setFontWeight('bold');
              });
   
              // putting customers data as next rows
              foreach ($member as $member) {
                  $sheet->appendRow(array($member -> nama_member, 
                    $member -> alamat_member,
                    $member -> tempat_lahir_member, 
                    $member -> tgl_lahir_member, 
                    $member -> jenis_kelamin_member,
                    $member -> no_hp_member));
              }
            });
   
          })->export('xls');
    }
    function print_laporan_member_berdasarkan_tgl_excel(){
        Excel::create('Laporan-Member', function($excel) {
            // Set the title
            $excel->setTitle('Expot to Excel');
            // Chain the setters
            $excel->setCreator('Effendy')
                  ->setCompany('PT CN Plus');
            // Call them separately
            $excel->sheet('Laporan Member', function ($sheet) {
   
            // first row styling and writing content
            $sheet->mergeCells('A1:W1');
            $sheet->row(1, function ($row) {
                $row->setFontFamily('Comic Sans MS');
                $row->setFontSize(15);
            });
   
            $sheet->row(1, array('Daftar Member'));
   
            // second row styling and writing content
            $sheet->row(2, function ($row) {
   
                // call cell manipulation methods
                $row->setFontFamily('Comic Sans MS');
                $row->setFontSize(10);
                $row->setFontWeight('bold');
   
            });
            $tgl_dari = $_REQUEST['tgl_dari'];
            $tgl_sampai = $_REQUEST['tgl_sampai'];

              $sheet->row(2, array('Laporan Daftar Member'));
              $member= DB::table('member')->where('is_delete','N')->whereBetween('date_input',[$tgl_dari,$tgl_sampai])->get();
   
              $column = array('Nama Member', 'Alamat Member','Tempat Lahir','Tanggal Lahir','Jenis Kelamin','No Hp');
   
              $sheet->appendRow($column);
   
              // getting last row number (the one we already filled and setting it to bold
              $sheet->row($sheet->getHighestRow(), function ($row) {
                  $row->setFontWeight('bold');
              });
   
              // putting customers data as next rows
              foreach ($member as $member) {
                  $sheet->appendRow(array($member -> nama_member, 
                    $member -> alamat_member,
                    $member -> tempat_lahir_member, 
                    $member -> tgl_lahir_member, 
                    $member -> jenis_kelamin_member,
                    $member -> no_hp_member));
              }
            });
   
          })->export('xls');
    }
}
