<?php

namespace App\Http\Controllers\Laporan;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Spipu\Html2Pdf\Html2Pdf;
use Maatwebsite\Excel\Facades\Excel;

class laporanPeminjamanController extends Controller
{
    public function view_laporan_peminjam(){
        $peminjaman = DB::table('pinjam')
        ->join('buku','pinjam.kd_buku', '=' ,'buku.kd_buku')
        ->join('member','pinjam.kd_member' , '=' , 'member.kd_member')
        ->select('pinjam.*','buku.*','member.*')->where('status',2)->where('keterangan','Pinjam')->get();
        return view('laporan-peminjaman.Laporan-Pinjam',['pinjam' => $peminjaman]);
    }
    public function print_laporan_peminjam_berdasarkan_tgl_pdf(){
        $Html2Pdf = new Html2Pdf('P','A4','en');
        
        $tgl_dari = $_REQUEST['tgl_dari'];
        $tgl_sampai = $_REQUEST['tgl_sampai'];
        
        $setting = DB::table('setting')->get()->first();
        $peminjaman = DB::table('pinjam')
        ->join('buku','pinjam.kd_buku', '=' ,'buku.kd_buku')
        ->join('member','pinjam.kd_member' , '=' , 'member.kd_member')
        ->select('pinjam.*','buku.*','member.*')->where('status',2)->where('keterangan','Pinjam')->whereBetween('tgl_pinjam',[$tgl_dari,$tgl_sampai])->get();
        
        $Html2Pdf->pdf->setTitle('Laporan Pinjam Buku');
        $Html2Pdf->writeHTML(view('laporan-peminjaman.Laporan-Pinjam-Pdf',['pinjam' => $peminjaman,'denda' => $setting->denda_per_hari]));
        $Html2Pdf->output('Laporan Pinjam Buku.pdf');
    }
    public function print_laporan_peminjam_pdf(){
        $Html2Pdf = new Html2Pdf('P','A4','en');
        $setting = DB::table('setting')->get()->first();
        $db = DB::table('pinjam')
        ->join('buku','pinjam.kd_buku','=', 'buku.kd_buku')
        ->join('member','pinjam.kd_member','=', 'member.kd_member')
        ->select('pinjam.*','buku.*','member.*')->where('pinjam.status',2)->where('keterangan','Pinjam')->get();

        $Html2Pdf->pdf->setTitle('Laporan Pinjam Buku');
        $Html2Pdf->writeHTML(view('laporan-peminjaman.Laporan-Pinjam-Pdf',['pinjam' => $db,'denda' => $setting->denda_per_hari]));
        $Html2Pdf->output('Laporan Pinjam Buku.pdf');
    }

    public function print_laporan_peminjam_excel(){
        Excel::create('Laporan Pinjam Buku', function($excel){
            $excel -> setTitle('Export to Excel');
            $excel -> setCreator('Effendy Wahyu')
                   -> setCompany('PT CN Plus');
            $excel ->sheet('Laporan Pinjam Buku', function($sheet){
                $sheet->mergeCells('A1:W1');
                $sheet->row(1, function($row){
                    $row->setFontFamily('Arial');
                    $row->setFontSize(14);
                });
                $sheet->row(1, array('Data Peminjam Buku'));
                $sheet->row(2, function($row){
                    $row->setFontFamily('Arial');
                    $row->setFontSize(10);
                    $row->setFontWeight('bold');
                });

                $sheet->row(2, array('Laporan Data Peminjam Buku'));
          
                $peminjam_buku = $db = DB::table('pinjam')
                ->join('buku','pinjam.kd_buku','=', 'buku.kd_buku')
                ->join('member','pinjam.kd_member','=', 'member.kd_member')
                ->select('pinjam.*','buku.*','member.*')->where('pinjam.status',2)->where('keterangan','Pinjam')->get();

                $column = array('No','Nama','Judul Buku','Tanggal Pinjam','Tanggal Kembali', 'Denda','Status');
                $sheet->appendRow($column);

                $sheet->row($sheet -> getHighestRow(), function ($row){
                    $row->setFontWeight('bold');
                });

                $no = 0;
                foreach($peminjam_buku as $pb){
                
                $setting = DB::table('setting')->get()->first();
                $no++;
                $tgl_hari_ini = date('Y-m-d');
                $tgl_kembali = $pb -> tgl_kembali;
                $interval = $this -> IntervalDays($tgl_kembali, $tgl_hari_ini);
                $denda = null;
                $status = null;
                if($interval < 0){
                    $denda += 0;
                    $status = "Masih Dipinjam";
                }else{
                   $denda += $interval * $setting->denda_per_hari;
                   $status = "Telat";
                }
                $sheet->appendRow(array($no,
                $pb -> nama_member,
                $pb -> judul_buku,
                $pb -> tgl_pinjam,
                $pb -> tgl_kembali,
                $denda,
                $status,
                ));
                }
            });
        })->export('xls');
    
    }
    public function print_laporan_peminjam_berdasarkan_tgl_excel(){      
        Excel::create('Laporan Pinjam Buku', function($excel){
            $excel -> setTitle('Export to Excel');
            $excel -> setCreator('Effendy Wahyu')
                   -> setCompany('PT CN Plus');
            $excel ->sheet('Laporan Pinjam Buku', function($sheet){
                $sheet->mergeCells('A1:W1');
                $sheet->row(1, function($row){
                    $row->setFontFamily('Arial');
                    $row->setFontSize(14);
                });
                $sheet->row(1, array('Data Peminjam Buku'));
                $sheet->row(2, function($row){
                    $row->setFontFamily('Arial');
                    $row->setFontSize(10);
                    $row->setFontWeight('bold');
                });

                $sheet->row(2, array('Laporan Data Peminjam Buku'));
                $tgl_dari = $_REQUEST['tgl_dari'];
                $tgl_sampai = $_REQUEST['tgl_sampai'];
          
                $peminjam_buku = $db = DB::table('pinjam')
                ->join('buku','pinjam.kd_buku','=', 'buku.kd_buku')
                ->join('member','pinjam.kd_member','=', 'member.kd_member')
                ->select('pinjam.*','buku.*','member.*')->where('pinjam.status',2)->where('keterangan','Pinjam')->whereBetween('tgl_pinjam',[$tgl_mulai,$tgl_selesai])->get();

                $column = array('No','Nama','Judul Buku','Tanggal Pinjam','Tanggal Kembali', 'Denda','Status');
                $sheet->appendRow($column);

                $sheet->row($sheet -> getHighestRow(), function ($row){
                    $row->setFontWeight('bold');
                });

                $no = 0;
                foreach($peminjam_buku as $pb){
                
                $setting = DB::table('setting')->get()->first();
                $no++;
                $tgl_hari_ini = date('Y-m-d');
                $tgl_kembali = $pb -> tgl_kembali;
                $interval = $this -> IntervalDays($tgl_kembali, $tgl_hari_ini);
                $denda = null;
                $status = null;
                if($interval < 0){
                    $denda += 0;
                    $status = "Masih Dipinjam";
                }else{
                   $denda += $interval * $setting->denda_per_hari;
                   $status = "Telat";
                }
                $sheet->appendRow(array($no,
                $pb -> nama_member,
                $pb -> judul_buku,
                $pb -> tgl_pinjam,
                $pb -> tgl_kembali,
                $denda,
                $status,
                ));
                }
            });
        })->export('xls');
    }
    function IntervalDays($day1,$day2){
        $checkIn = explode("-",$day1);
        $checkOut = explode("-",$day2);

        $date1 = mktime(0, 0, 0, $checkIn[1], $checkIn[2], $checkIn[0]);
        $date2 = mktime(0, 0, 0, $checkOut[1],$checkOut[2],$checkOut[0]);
        $interval = ($date2 - $date1) / (3600 * 24);
        return $interval;
    }
}
