<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Contracts\Encryption\DecryptException;

date_default_timezone_set('Asia/Jakarta');
class AdminController extends Controller
{
    public function restore_admin($id){
        $db = DB::table('admin')->where('kd_admin',$id)->update([
            'delete_by' => null,
            'delete_date' => null,
            'is_delete' => 'N'
        ]);
        return redirect("/data-admin");
    }
    public function trash_admin(){
        $db = DB::table('admin')->where('is_delete','Y')->get();
        return view('admin.trash_admin',['admin' => $db]);
    }
    public function input_admin(Request $request){
            $file_image = $request->file('foto-admin');
            $ext = $file_image->getClientOriginalExtension();
            $nama_image = rand(100000, 1001238912).".".$ext;
            $file_image->move('upload-foto-member',$nama_image);

        DB::table('admin')->insert([
            'nip_admin' => $request->nip,
            'nama_admin' => $request->nama,
            'jenis_kelamin_admin'=> $request->jenis_kelamin,
            'alamat_admin' => $request->alamat,
            'tempat_lahir_admin' => $request->tempat_lahir,
            'tgl_lahir_admin' => $request->tgl_lahir,
            'no_hp_admin' => $request->no_hp,
            'foto_admin' => $nama_image,
            'email' => $request->email,
            'password' => md5($request->password),
            'level' => $request->level,
            'created_by' => $request->kd_operator,
            'created_date' => date('Y-m-d H:i:s'),
            'update_by' => null,
            'update_date' => null,
            'delete_by' => null,
            'delete_date' => null,
            'is_delete' => 'N'
        ]);
        return redirect('/data-admin');
    }
    //
	public function Login(){
		  $email = "wahyupradana729@gmail.com";
            $pass = md5(123);
            $db = DB::table('admin')->where(function ($query) use ($email,$pass){
                $query->where('email',$email);
                $query->where('password',$pass);
            })->get();
           
            
            return collect($db->toArray());
            //return view('admin.login_admin');
	}

    public function ViewRegistrasi(){
    	return view('admin.register_admin');
    }
    public function InputRegistrasi(Request $request){
    	
			$email = $_POST['email'];
			$host = mysqli_connect('localhost','root','','perpustakaan');
			$query = mysqli_query($host,"SELECT * FROM admin WHERE email='$email'");
			$arr = mysqli_fetch_array($query);

			if($email == $arr['email']){
				echo "<script>alert('Email Sudah Terdaftar')</script>";
				return redirect('/register');
			}else{
				$db = DB::table('admin')->insert([
					'nama_admin' => $request->nama,
					'email' => $request->email,
					'password' => md5($request->password)
				]); 
				return redirect('/');
			}
		}
    
    public function InputLogin(Request $request){
    		$email = $request->email;
            $pass = $request->password;
            $is_delete = 'N';
    		$db = DB::table('admin')->where(function ($query) use ($email,$pass,$is_delete){
    			$query->where('email',$email);
                $query->where('password',md5($pass));
                $query->where('is_delete',$is_delete);
    		});
            $count = $db->get()->count();
			
    		if($count != 0){
				$arr = $db->first();
				session::put('login','OK');
                session::put('kd_admin',$arr->kd_admin);
				session::put('name',$arr->nama_admin);
				session::put('email',$arr->email);
                session::put('level', $arr->level);
                session::put('image_profil',$arr->foto_admin);
                return redirect('/dashboard');
    		}else{
    			return redirect('/');
    		}

    	}

    public function SessionLogin(){
    	if(session::get('login')){
    		return view('index');
    	}else{
    		return view('admin.login_admin');
    	}
    }
    public function SignOut(){
        session::forget('login');
        return redirect('/');
    }
    public function view_data_admin(){
        $db = DB::table('admin')->where('is_delete','N')->get();
        return view('admin.data_admin',['admin' => $db]);
    }
    public function hapus_data_admin($id,$kd_admin){
        DB::table('admin')->where('kd_admin',$id)->update([
            'delete_by' => $kd_admin,
            'delete_date' => date('Y-m-d H:i:s'),
            'is_delete' => 'Y'
        ]);
        return redirect('/data-admin');
    }
    public function view_input_data_admin(){
        return view('admin.input_data_admin');
    }

    //Edit Admin
    public function view_edit_admin($id){
        $select_admin = DB::table('admin')->where('kd_admin',$id)->get();
        return view('admin.edit_admin',['admin' => $select_admin]);
    }
    public function edit_admin(Request $request){
        $kd_admin = $request->kd_admin;
        $nip_admin = $request->nip;
        $nama_admin = $request->nama;
        $alamat_admin = $request->alamat;
        $tempat_lahir_admin = $request->tempat_lahir;
        $tgl_lahir_admin = $request->tgl_lahir;
        $no_hp_admin = $request->no_hp;
        $foto_admin = $request->file('foto-admin');
        //Upload Foto
        $ext = $foto_admin->getClientOriginalExtension();
        $nama_image = rand(100000, 1001238912).".".$ext;
        $foto_admin->move('upload-foto-member',$nama_image);
        //End Upload Foto
        $email_admin = $request->email;
        $password_admin = $request->password;
        $level = $request->level;

        DB::table('admin')->where('kd_admin',$kd_admin)->update([
            'nip_admin' => $nip_admin,
            'nama_admin' => $nama_admin,
            'alamat_admin' => $alamat_admin,
            'tempat_lahir_admin' => $tempat_lahir_admin,
            'tgl_lahir_admin' => $tgl_lahir_admin,
            'no_hp_admin' => $no_hp_admin,
            'foto_admin' => $nama_image,
            'email' => $email_admin,
            'password' => md5($password_admin),
            'level' => $level,
            'update_by' => $request ->kd_operator,
            'update_date' => date('Y-m-d H:i:s')
        ]);

        return redirect('/data-admin');
    }
}
