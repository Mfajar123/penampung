<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class mahasiswaController extends Controller
{
    //
    public function pendaftaran(){
        return view('pendaftaran_mahasiswa_baru.pendaftaran_mahasiswa_baru');
    }
}
