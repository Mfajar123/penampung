<?php

namespace App\Http\Controllers\Pendaftaran_Mahasiswa;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Alert;

class pendaftaran_mahasiswaController extends Controller
{
    //
    public function automatic_number_registration(){
        $query = DB::table('pendaftar')->max('kd_daftar');
        return sprintf("%03s", abs($query + 1));
    }

    public function data_pendaftar(){
        $data_pendaftar = DB::table('pendaftar')->get();
        return view('pendaftaran_mahasiswa_baru.data_pendaftaran_mahasiswa_baru',['pendaftar' => $data_pendaftar]);
    }

    public function pendaftaran(){
        return view('pendaftaran_mahasiswa_baru.pendaftaran_mahasiswa_baru');
     }
    public function input_pendaftar(Request $request){
        $no_otomatis = $this->automatic_number_registration();
        $nama = $request->nama;
        $no_tlp = $request->no_telp;
        $alamat = $request->alamat;
        $provinsi = $request->provinsi;
        $jenkel = $request->jenkel;
        $tempat_lahir = $request->tempat_lahir;
        $tgl_lahir = $request->tgl_lahir;
        $prodi = $request->prodi;
        $waktu_kuliah = $request->waktu_kuliah;
        $asal_sekolah = $request->asal_sekolah;


        $insert = DB::table('pendaftar')->insert([
            'kd_daftar' => $no_otomatis,
            'nama' => $nama,
            'no_telp' => $no_tlp,
            'alamat' => $alamat,
            'provinsi' => $provinsi,
            'jenis_kelamin' => $jenkel,
            'tempat_lahir' => $tempat_lahir,
            'tgl_lahir' => $tgl_lahir,
            'prodi' => $prodi,
            'waktu_kuliah' => $waktu_kuliah,
            'tgl_daftar' => date('Y-m-d H:i:s'),
            'asal_sekolah' => $asal_sekolah
        ]);
        Alert::message('Data Pendaftaran Anda Berhasil Di simpan', 'Terima Kasih')->autoclose(5000);
        return redirect('pendaftaran_mahasiswa');
    }
}
