<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Khill\Lavacharts\Lavacharts;

class chartsController extends Controller
{
    //
    public function chart(){
    	$buku = DB::table('kategori')->where('is_delete','N')->get();
		return view('dashboard.dashboard',['pinjam' => $buku]);
    }
}
