<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Spipu\Html2Pdf\Html2Pdf;

class PeminjamanController extends Controller
{
    public function PeminjamanBuku(){
        $db = DB::table('buku')->where('is_delete','N')->get();
        $member = DB::table('member')->where('is_delete','N')->get();
        return view('peminjaman.peminjaman',['buku'=>$db,'member'=>$member]);
    }
    public function cariMember(Request $request){
        $cari = $request->kd_member;
        $member = DB::table('member')->where('kd_member',"=",$cari)->where('is_delete','N')->paginate();
        return view('peminjaman.peminjaman-buku',['member' => $member]);
    }
    public function pinjam_buku($kd_member){
        $edit = DB::table('pinjam')->where('kd_member',$kd_member)->where('status',1)->update([
            'status' => 2
        ]);
        return redirect('/data-pinjam-buku');
    }
    public function hapus_pinjam_buku($kd_member, $kd_buku){
        $hapus = DB::table('pinjam')->where('kd_member',$kd_member)->where('kd_buku',$kd_buku)->delete();
        return redirect('/peminjaman-buku/?kd_member='.$kd_member);
    }
    public function SimpanPinjamBuku(Request $request){
        $kd_member = $request->kd_member;
        $kd_buku = $request->kd_buku;
        $pilih = DB::table('pinjam')->where('kd_member',$kd_member)->first();
        $setting = DB::table('setting')->get()->first();
        $hitung = DB::table('pinjam')->where('kd_member', $kd_member)->where('status',1)->count();
        $status_pinjam = DB::table('pinjam')->where('kd_member', $kd_member)->where('status',2)->count();
        $status_pinjam_buku_terpisah = DB::table('pinjam')->where('kd_member',$kd_member)->where('keterangan','Pinjam')->count();
            
            $buku = DB::table('buku')->where('kd_buku',$kd_buku)->where('is_delete','N')->get()->first();
            $count_book = DB::table('pinjam')->where('kd_buku',$kd_buku)->where('keterangan','Pinjam')->count();
             
            $count_setting = $setting->jumlah_max_pinjam_buku;
            if($count_book >= $buku->jumlah_buku){
                return "<script type='text/javascript'>alert('Buku Tidak Tersedia');
            document.location='/peminjaman-buku/?kd_member=$request->kd_member';
            </script>";
            }else if($hitung >= $count_setting){
                 return "<script type='text/javascript'>alert('Sudah Melewati Batas Maximal');
            document.location='/peminjaman-buku/?kd_member=$request->kd_member';
            </script>";
            }elseif($status_pinjam >= $count_setting){
            return "<script type='text/javascript'>alert('Anda Sudah Pinjam');
            document.location='/peminjaman-buku/?kd_member=$request->kd_member';
            </script>";
            }elseif($status_pinjam_buku_terpisah >= $count_setting){
            return "<script type='text/javascript'>alert('Sudah Tidak Bisa Pinjam');
            document.location='/peminjaman-buku/?kd_member=$request->kd_member';
            </script>";
            }else{
                date_default_timezone_set('Asia/Jakarta');
            DB::table('pinjam')->insert([
                'kd_buku' => $request->kd_buku,
                'kd_member' => $request->kd_member,
                'tgl_pinjam' => $request->tgl_pinjam,
                'tgl_kembali' => $request->tgl_kembali,
                'status' => 1,
                'jumlah_buku_pinjam' => 1,
                'keterangan' => 'Pinjam',
                'created_by' => $request->kd_admin,
                'created_date' => date('Y-m-d H:i:s')
            ]);
            return redirect('/peminjaman-buku/?kd_member='.$request->kd_member);
          }
           
           
        }
       // return $pilih->status;
    
    public function DataPinjamBuku(){
    	$db = DB::table('pinjam')
    	->join('buku','pinjam.kd_buku', '=', 'buku.kd_buku')
    	->join('member','pinjam.kd_member','=', 'member.kd_member')
    	->select('pinjam.*', 'buku.*', 'member.*')->where('pinjam.status',2)
    	->paginate(10);

			
    	return view('peminjaman.data-peminjaman',['data_pinjam' => $db]);
    }
    public function ReportPinjamBuku(){
        $Html2Pdf = new Html2Pdf('P','A4','en');
        $db = DB::table('pinjam')
        ->join('buku','pinjam.kd_buku','=', 'buku.kd_buku')
        ->join('member','pinjam.kd_member','=', 'member.kd_member')
        ->select('pinjam.*','buku.*','member.*')->where('pinjam.status',1)->get();
        $Html2Pdf->pdf->setTitle('Laporan Pinjam');
        $Html2Pdf->writeHTML(view('laporan.Laporan-Pinjam',['pinjam' => $db]));
        $Html2Pdf->output('Laporan-Pinjam.pdf');

    }
}
