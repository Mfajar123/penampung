<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Spipu\Html2Pdf\Html2Pdf;

class BukuController extends Controller
{
             
  public function searchBuku(Request $request){
    $cari = $request->cari_buku;
    $buku = DB::table('buku')->where('judul_buku','like',"%".$cari."%")->paginate();
    return view('buku.MasterBuku',['buku' => $buku]);

  }
  public function detailBuku($id){
    $buku = DB::table('buku')
    ->join('kategori','buku.kd_kategori', '=' ,'kategori.kd_kategori')
    ->select('kategori.*','buku.*')->where('buku.kd_buku',$id)->get();
    return view('buku.DetailBuku',['buku' => $buku]);
  }
  public function Buku(){
   $buku = $db = DB::table('buku')
   ->join('kategori','buku.kd_kategori', '=', 'kategori.kd_kategori')
   ->select('kategori.*', 'buku.*')->where('buku.is_delete','N')
   ->paginate(10);
   return view('buku.MasterBuku',['buku' => $buku]);
 }
 public function ViewInputBuku(){

  date_default_timezone_set('Asia/Jakarta');
   $kategori_buku = DB::table('kategori')->where('is_delete','N')->get();
   $tipe = DB::table('tipe')->where('is_delete','N')->get();
   return view('buku.InputBuku',['kategori_buku' => $kategori_buku,'tipe' => $tipe]);
 }
 public function InputBuku(Request $request){
  $file_image = $request->file('foto');  
  $file_pdf = $request->file('ebook');
  if($file_pdf == null){
    $name_pdf = null;
  }else{
    $pdf = $file_pdf->getClientOriginalExtension();
    $name_pdf = rand(100000, 1001238912).".".$pdf;
    $file_pdf->move('upload-ebook',$name_pdf);
  }
 

  $ext = $file_image->getClientOriginalExtension();
  $newName = rand(100000, 1001238912).".".$ext;
  $file_image->move('upload-foto-buku',$newName);

    //
  date_default_timezone_set('Asia/Jakarta');
  $input = DB::table('buku')->insert([
    'judul_buku' => $request->judul,
    'penulis' => $request->penulis,
    'penerbit' => $request->penerbit,
    'kd_kategori' => $request->kategori,
    'jumlah_buku' => $request->jumlah_buku,
    'foto_sampul' => $newName,
    'deskripsi_buku' => $request->deskripsi,
    'jumlah_buku_dipinjam' => 0,
    'ebook' => $name_pdf,
    'isbn' => $request->isbn,
    'edisi' => $request->edisi,
    'bahasa' => $request->bahasa,
    'tipe' => $request->tipe,
    'tahun_terbit' => $request->tahun_terbit,
    'tempat_terbit' => $request->tempat_terbit,
    'created_by' => $request->kd_admin,
    'created_date' => date('Y-m-d H:i:s'),
    'update_by' => null,
    'update_date' => null,
    'delete_by' => null,
    'delete_date' => null,
    'is_delete' => 'N',
    'date_input' => date('Y-m-d')
  ]);

  return redirect('/buku');
}
public function HapusBuku($id,$kd_admin){
  //$hapus = DB::table('buku')->where('kd_buku',$id)->delete();

  date_default_timezone_set('Asia/Jakarta');
  $hapus = DB::table('buku')->where('kd_buku',$id)->update([
      'delete_by' => $kd_admin,
      'delete_date' => date('Y-m-d H:i:s'),
      'is_delete' => 'Y' 
  ]);
  return redirect('/buku');
}
public function ViewEditBuku($id){
  $edit = DB::table('buku')->where('kd_buku',$id)->get();
  $kategori = DB::table('kategori')->get();
  return view('buku.EditBuku',['buku'=>$edit, 'kategori_buku' => $kategori]);
}
public function TrashBuku(){
  $trash = DB::table('buku')->where('is_delete','Y')->get();
  return view('buku.TrashBuku',['file_trash' => $trash]);
}
public function RestoreBuku($id){
  $restore = DB::table('buku')->where('kd_buku',$id)->update([
    'delete_by' => null,
    'delete_date' => null,
    'is_delete' => 'N'
  ]);
  return redirect('/buku');
}

public function EditEbook(Request $request){
  $kd_buku = $request->kd_buku;
  $file_pdf = $request->file('ebook');

  $pdf = $file_pdf->getClientOriginalExtension();
  $name_pdf = rand(100000, 1001238912).".".$pdf;
  $file_pdf->move('upload-ebook',$name_pdf);
  
  $edit_buku = DB::table('buku')->update([
      'ebook' => $name_pdf
  ])->where('kd_buku', $kd_buku);
}

public function EditBuku(Request $request){
  $file_image = $request->file('foto');  
  $ext = $file_image->getClientOriginalExtension();
  $newName = rand(100000, 1001238912).".".$ext;
  $file_image->move('upload-foto-buku',$newName);

    //
  date_default_timezone_set('Asia/Jakarta');
  $input = DB::table('buku')->where('kd_buku', $request->kd_buku)->update([
    'judul_buku' => $request->judul,
    'penulis' => $request->penulis,
    'penerbit' => $request->penerbit,
    'kd_kategori' => $request->kategori,
    'jumlah_buku' => $request->jumlah_buku,
    'foto_sampul' => $newName,
    'deskripsi_buku' => $request->deskripsi,
    'jumlah_buku_dipinjam' => 0,
    'isbn' => $request->isbn,
    'edisi' => $request->edisi,
    'bahasa' => $request->bahasa,
    'kd_tipe' => $request->kd_tipe,
    'tempat_terbit' => $request->tempat_terbit,
    'tahun_terbit' => $request->tahun_terbit,
    'update_by' => $request->kd_admin,
    'update_date' => date('Y-m-d H:i:s')
  ]);

  return redirect('/buku');
}
public function report_buku(){
  $Html2Pdf = new Html2Pdf('P','A4','en');
  $buku = DB::table('buku')->get();
  $Html2Pdf->pdf->SetTitle('Daftar Buku');
  $Html2Pdf->writeHTML(view('laporan.Laporan-Buku',['buku'=>$buku]));
  $Html2Pdf->output('daftar-buku.pdf');
}
}
