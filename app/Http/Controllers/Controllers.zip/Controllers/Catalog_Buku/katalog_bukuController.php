<?php

namespace App\Http\Controllers\Catalog_Buku;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Ixudra\Curl\Facades\Curl;

class katalog_bukuController extends Controller
{
    //Fungsi Data Buku Berdasarkan Descending Kode Buku
    public function buku(){
        $table_buku = DB::table('buku')->where('is_delete','N')->orderBy('kd_buku','DESC')->take(8)->get();
        return $table_buku;
    }
    //Fungsi Data Kategori
    public function kategori(){
        $table_kategori_buku = DB::table('kategori')->where('is_delete','N')->get();
        return $table_kategori_buku;
    }
    public function data_buku(){
        $data_buku = $this->buku();
        $data_kategori = $this->kategori();
        return view('katalog-buku.data_katalog_buku',['buku' => $data_buku,'kategori' => $data_kategori]);
    }
    public function koleksi_buku(){
    $table_buku = DB::table('buku')->where('is_delete','N')->paginate(12);
    $data_kategori = $this->kategori();
    if($table_buku == null){
        echo "Tidak Ada";
    }
       return view('katalog-buku.koleksi_buku',['buku' => $table_buku,'kategori' => $data_kategori]);
    }
    public function detail_buku(){
        $kd_buku = $_REQUEST['kd_buku'];
        $table_kategori_buku = DB::table('kategori')->where('is_delete','N')->get();
        $table_buku = DB::table('buku')->where('is_delete','N')->where('kd_buku',$kd_buku)->paginate(12);
        return view('katalog-buku.detail_katalog_buku',['buku' => $table_buku,'kategori' => $table_kategori_buku]);
    }
    public function cari_buku_koleksi(){
        $judul = $_REQUEST['judul'];
        $kategori = $this->kategori();
        $table_buku = DB::table('buku')->where('is_delete','N')->where('judul_buku','like',"%".$judul."%");
        if($table_buku->count() > 0){
        return view('katalog-buku.koleksi_buku',['buku' => $table_buku->paginate(12),'kategori' =>$kategori]);
        }else{
        return "<script>alert('Data Tidak Ada');
        document.location='koleksi-buku'</script>";
        }
    }
    public function cari_buku(){
        $judul = $_REQUEST['cari'];
        $table_kategori_buku = DB::table('kategori')->where('is_delete','N')->get();
        $table_buku = DB::table('buku')->where('is_delete','N')->where('judul_buku','like',"%".$judul."%")->paginate(12);
        return view('katalog-buku.data_katalog_buku',['buku' => $table_buku,'kategori' => $table_kategori_buku]);
    }
    public function data_buku_kategori(){
        $kd_kategori = $_REQUEST['kd_kategori'];
        $table_kategori_buku = DB::table('kategori')->where('is_delete','N')->get();
        $table_buku = DB::table('buku')->where('is_delete','N')->where('kd_kategori',$kd_kategori)->paginate(12);
        
        return view('katalog-buku.koleksi_buku',['buku' => $table_buku,'kategori' => $table_kategori_buku]);
    }
    public function belajar_API(){
        $response = Curl::to('https://www.thesportsdb.com/api/v1/json/1/eventsnextleague.php?id=4328')
        ->get();
        $api_detail_team = Curl::to('https://www.thesportsdb.com/api/v1/json/1/lookupteam.php?id=');
        $json = json_decode($response,true);
      
        return view('belajar_API.belajar_api',['api' => $json]);
    }
}
