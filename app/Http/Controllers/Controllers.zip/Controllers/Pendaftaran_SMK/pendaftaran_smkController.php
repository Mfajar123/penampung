<?php

namespace App\Http\Controllers\Pendaftaran_SMK;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Alert;
class pendaftaran_smkController extends Controller
{
    //
    public function automatic_number_registration(){
        $query = DB::table('pendaftar_smk')->max('kode_pendaftar');
        return sprintf("%03s", abs($query + 1));
    }
    public function pendaftaran_smk(){
        return view('pendaftaran_siswa_baru.pendaftaran_siswa_baru');
    }
    public function input_pendaftaran_smk(Request $request){
        $no_otomatis = $this->automatic_number_registration();
        $nama = $request->nama;
        $tempat_lahir = $request->tempat_lahir;
        $tgl_lahir = $request->tgl_lahir;
        $jenkel = $request->jenkel;
        $alamat = $request->alamat;
        $no_telp = $request->no_telp;
        $nama_ayah = $request->nama_ayah;
        $nama_ibu = $request->nama_ibu;
        $alamat_orang_tua = $request->alamat_orang_tua;
        $no_telp_orang_tua = $request->no_telp_orang_tua;
        $pekerjaan_ayah = $request->pekerjaan_ayah;
        $pekerjaan_ibu = $request->pekerjaan_ibu;
        $nisn = $request->nisn;
        $no_ijazah = $request->no_ijazah;
        $tahun_lulus = $request->tahun_lulus;
        $asal_sekolah = $request->asal_sekolah;
        $jurusan = $request->jurusan;

        $insert = DB::table('pendaftar_smk')->insert([
            'kode_pendaftar' => $no_otomatis,
            'nama_lengkap' => $nama,
            'tempat_lahir' => $tempat_lahir,
            'tgl_lahir' => $tgl_lahir,
            'jenis_kelamin' => $jenkel,
            'alamat_asal' => $alamat,
            'no_telp' => $no_telp,
            'nama_ayah_kandung' => $nama_ayah,
            'nama_ibu_kandung' => $nama_ibu,
            'alamat_orang_tua' => $alamat_orang_tua,
            'no_telp_orang_tua' => $no_telp_orang_tua,
            'pekerjaan_ayah' => $pekerjaan_ayah,
            'pekerjaan_ibu' => $pekerjaan_ibu,
            'nisn' => $nisn,
            'tahun_lulus' => $tahun_lulus,
            'no_ijazah' => $no_ijazah,
            'asal_sekolah' => $asal_sekolah,
            'jurusan' => $jurusan,
            'tgl_daftar' => date('Y-m-d H:i:s')
        ]);
        Alert::message('Data Pendaftaran Anda Berhasil Di Simpan', 'Terima Kasih')->autoclose(5000);
        return redirect('pendaftaran_siswa');
    }
}
