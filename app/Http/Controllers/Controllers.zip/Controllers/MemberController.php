<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Spipu\Html2Pdf\Html2Pdf;

date_default_timezone_set('Asia/Jakarta');
class MemberController extends Controller
{
	//
	function restore_member($id){
		$member = DB::table('member')->where('kd_member',$id)->update([
			'delete_by' => null,
			'delete_date' => null,
			'is_delete' => 'N'
		]);
		return redirect('/member');
	}
	function trash_member(){
		$member = DB::table('member')->where('is_delete','Y')->get();
		return view('member.trash-member',['member' => $member]);
	}
    function ViewMasterMember(){
    	$member = DB::table('member')->where('is_delete','N')->paginate(10);
    	return view('member.mastermember',['member' => $member]);
    }
    function ViewInputMember(){
    	return view('member.inputmember');
    }
    function InputMember(Request $request){
		
    	$member = DB::table('member')->insert([
    		'nama_member' => $request->nama_member,
    		'alamat_member' => $request->alamat_member,
    		'tempat_lahir_member' => $request->tempat_lahir_member,
    		'tgl_lahir_member' => $request->tgl_lahir_member,
			'jenis_kelamin_member' => $request->jenis_kelamin_member,
			'level_member' => $request->level_member,
			'no_hp_member' => $request->no_hp_member,
			'created_by' => $request->kd_admin,
			'created_date' => date('Y-m-d H:i:s'),
			'update_by' => null,
			'update_date' => null,
			'delete_by' => null,
			'delete_date' => null,
			'is_delete' => 'N'
    	]);
    	return redirect('/member');
    }
    function CariMember(Request $request){
    	$cari = $request->cari;
    	$member = DB::table('member')->where('is_delete','N')->where('nama_member','like',"%".$cari."%")->paginate(10);
    	return view('member.mastermember',['member' => $member]);
    }
    function HapusMember($id,$kd_admin){
    	$member = DB::table('member')->where('kd_member',$id)->update([
			'delete_by' => $kd_admin,
			'delete_date' => date('Y-m-d H:i:s'),
			'is_delete' => 'Y'
		]);
    	return redirect('/member');
    }
    function ViewEditMember($id){
    	$member = DB::table('member')->where('kd_member', $id)->get();
    	return view('member.EditMember',['member' => $member]);
    }
    function EditMember(Request $request){
    	$member = DB::table('member')->where('kd_member',$request->kd_member)->update([
    		'nama_member' => $request->nama_member,
    		'alamat_member' => $request->alamat_member,
    		'tempat_lahir_member' => $request->tempat_lahir_member,
    		'tgl_lahir_member' => $request->tgl_lahir_member,
            'jenis_kelamin_member' => $request->jenis_kelamin_member,
			'no_hp_member' => $request->no_hp_member,
			'level_member' => $request->level_member,
			'update_by' => $request->kd_admin,
			'update_date' => date('Y-m-d H:i:s')
    	]);
    	return redirect('/member');
    }
    function ReportMember(){
		$Html2Pdf = new Html2Pdf('P','A4','en');
        $member = DB::table('member')->where('is_delete','N')->get();
        $Html2Pdf->pdf->setTitle('Laporan Member');
        $Html2Pdf->writeHTML(view('laporan.Laporan-Member',['member' => $member]));
		$Html2Pdf->output('Laporan-Member.pdf');
    }
}
