<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Alert;

date_default_timezone_set('Asia/Jakarta');
class TipeBukuController extends Controller
{
    //
    public function view_data_buku_from_db(){
        $db = DB::table('tipe')->where('is_delete','N')->get();
        return $db;
    } 
    public function tipe_buku(){
        $db = $this->view_data_buku_from_db();
        return view('tipe_buku.tipe_buku',['tipe' => $db]);
    }
    public function delete_tipe_buku($id,$nama){
        DB::table('tipe')->where('kd_tipe',$id)->update([
            'delete_by' => $nama,
            'delete_date' => date('Y-m-d H:i:s'),
            'is_delete' => 'Y'
        ]); 
        Alert::message('Data Dihapus', 'Terima Kasih')->autoclose(5000);
        return redirect('tipe-buku');
    }
    public function edit_view_tipe_buku($id){
        $db = DB::table('tipe')->where('kd_tipe',$id)->get();
        return view('tipe_buku.edit_tipe_buku',['tipe'=>$db]);
    }
    public function edit_tipe_buku(Request $request){
        $db = DB::table('tipe')->where('kd_tipe',$request->id_tipe_buku)->update([
            'tipe_buku' => $request->tipe_buku,
            'update_by' => $request->nama_admin,
            'update_date' => date('Y-m-d H:i:s')  
        ]);
        return redirect('tipe-buku');
    }
    public function trash_view_tipe_buku(){
        $db = DB::table('tipe')->where('is_delete','Y')->get();
        return view('tipe_buku.trash_tipe_buku',['tipe' => $db]);
    }
    public function restore_tipe_buku($id){
        $db = DB::table('tipe')->where('kd_tipe',$id)->update([
            'delete_by' => null,
            'delete_date' => null,
            'is_delete' => 'N'
        ]);
        return redirect('tipe-buku');
    }
    public function input_tipe_buku(Request $request){
        $db = DB::table('tipe')->insert([
            'tipe_buku' => $request->tipe,
            'create_by' => $request->nama_admin,
            'create_date' => date('Y-m-d H:i:s'),
            'update_by' => null,
            'update_date'=> null,
            'delete_by' => null,
            'delete_date' => null,
            'is_delete' => 'N'
        ]);
        Alert::message('Data Dihapus', 'Terima Kasih')->autoclose(5000);
        return redirect('tipe-buku');
    }
}
