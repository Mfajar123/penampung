<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class SettingController extends Controller
{
    //
    public function view_setting(){
    	$setting = DB::table('setting')->get();
    	return view('setting.setting',['setting' => $setting]);
    }
    public function edit_setting(Request $request){
		date_default_timezone_set('Asia/Jakarta');
    	DB::table('setting')->where('kd_setting' ,$request->kd_setting)->update([
    		'batas_max_hari_pinjam' => $request->batas_max_hari_pinjam,
    		'denda_per_hari' => $request->denda_per_hari,
			'jumlah_max_pinjam_buku' => $request->jumlah_max_pinjam_buku,
			'update_by' => $request->kd_admin,
			'update_date' => date('Y-m-d H:i:s')
    	]);
    	return redirect('/setting');
    }
}
