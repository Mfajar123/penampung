<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class KategoriController extends Controller
{
    //
    public function viewKategori(){
        $db = DB::table('kategori')->where('is_delete','N')->paginate(10);
        return view('kategori.MasterKategori',['kategori' => $db]);
    }
    public function viewInputKategori(){
    	return view('kategori.Input-Kategori');
    }
    public function restoreKategori($id){
        $db = DB::table('kategori')->where('kd_kategori',$id)->update([
            'delete_by' => null,
            'delete_date' => null,
            'is_delete' => 'N'
        ]);
        return redirect('kategori-buku');
    }
    public function trashKategori(){
        $db = DB::table('kategori')->where('is_delete','Y')->paginate(10);
        return view('kategori.TrashKategori',['trashKategori' => $db]);
    }
    public function InputKategori(Request $request){
        $kategori = $request->kategori;
        $file_image = $request->file('file');
        $kd_admin = $request->kd_admin;
        
        date_default_timezone_set('Asia/Jakarta');
        $ext = $file_image->getClientOriginalExtension();
        $newName = rand(100000, 1001238912).".".$ext;
        $file_image->move('upload-foto-kategori',$newName);
    	$db = DB::table('kategori')->insert([
            'kategori' => $kategori,
            'foto_sampul' => $newName,
            'created_by' => $kd_admin,
            'created_date' => date('Y-m-d H:i:s'),
            'update_by' => null,
            'update_date' => null,
            'delete_by' => null,
            'delete_date' => null,
            'is_delete' => 'N'
        ]);
        
    	return redirect('/kategori-buku');
    }
    public function HapusKategori($id){
        $db = DB::table('kategori')->where('kd_kategori',$id)->update([
            'is_delete' => 'Y'
        ]);
        return redirect('/kategori-buku');
    }
    public function editViewKategori($id){
        $db = DB::table('kategori')->where('kd_kategori',$id)->get();
        return view('kategori.Edit-Kategori',['kategori' => $db]);
    }
    public function editKategori(Request $request){
        $id = $request->kd_kategori;
        $kategori = $request->kategori;
        $kd_admin = $request->kd_admin;
        $file_image = $request->file('file');

        date_default_timezone_set('Asia/Jakarta');
        $ext = $file_image->getClientOriginalExtension();
        $newName = rand(100000, 1001238912).".".$ext;
        $file_image->move('upload-foto-kategori',$newName);

        $db = DB::table('kategori')->where('kd_kategori', $id)->update([
            'kategori'=>$request->kategori,
            'foto_sampul' => $newName,
            'update_by' => $kd_admin,
            'update_date' => date('Y-m-d H:i:s')
        ]);
        return redirect('/kategori-buku');
    }
}
