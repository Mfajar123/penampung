<form action="">
<div class="form-group">
	{!! Form::label('id_daftar', 'Nama Calon Mahasiswa Pindahan', ['class' => 'control-label']) !!}
	{!! Form::select('id_daftar', $list_nama, null, ['placeholder' => '- Pilih Nama Calon Mahasiswa Pindahan  -', 'class' => 'form-control select-custom', 'width' => '100%', 'required']) !!}
</div>
	<table class='table table-bordered table-striped'>
		<thead>
			<tr>
				<th>Nama Mata Kuliah</th>
				<th>SKS</th>
				<th>Aksi</th>
			</tr>
		</thead>
		<tbody id="tambah_row">
				<tr>
					<td>
						<input type="text" value="" placeholder="Nama Matkul" name="nama_matkul[]" class="form-control" id="matkul_1">
					</td>
					<td>
						<input type="text" value="" placeholder="SKS" name="sks[]" class="form-control" id="sks_1">
					</td>
					<td>
						<button type="button" class="btn btn-danger btn_remove_jadwal" disabled><i class="fa fa-remove" ></i></button>
					</td>
				</tr>
		</tbody>
			<tr>
				<td colspan='6'><button type='button' class='btn btn-default btn_tambah_field'>Tambah Matkul</button></td>
			</tr>
	</table>

	{!! Form::submit($btn_submit_text, ['id' => 'btn_submit_form', 'class' => 'btn btn-primary', 'data-loading-text' => 'Loading...']) !!}
	<a href="{{ route('admin.jadwal_ujian') }}" class="btn btn-default">Batal</a>
</form>

<div style="display:none;">
	
		<table>	
			<tr id="salin" > 
				<td>
					<input type="text" value="" placeholder="Nama Matkul" name="nama_matkul[]" class="form-control" id="field_matkul">
				</td>
				<td>
					<input type="text" value="" placeholder="SKS" name="sks[]" class="form-control" id="field_sks">
				</td>
			</tr>
		</table>
	</div>
	
@section ('script')
	<script type="text/javascript">

		$(document).ready(function() {

			//SCRIPT TAMBAH Baris
			var max_fields 	= 50; //max field yg bisa ditambahkam
			var wrapper 	= $('#tambah_row #baris').length; // filed wrapper
			var add_button	= $('.btn_tambah_field'); // tombol add

			var x 			= 1;

			$(add_button).click(function() {
				
				var no	=  parseInt($('#nomor_doang').val());
				var data 		= $('#salin').html();

				var next_no = no + 1;


				$('#nomor_doang').val(next_no);

				data = data.replace(new RegExp('field_matkul', 'g'), 'matkul_' + next_no);
				data = data.replace(new RegExp('field_sks', 'g'), 'sks_' + next_no);

				if ( x < max_fields) {
					x++;
					$('#xxxxxxx').val('');
					$('#tambah_row').append('<tr id="baris' + next_no + '">' + data +'<td><a href="#" class="btn btn-danger" id="hapus_baris" data-field="' + next_no + '" onclick="hapus_baris(' + next_no + ')"><i class="fa fa-remove"></i></a></td></div>');
				}

			});
		});

		function hapus_baris(no){

			$('#baris' + no).remove();

		}
	</script>
	<input type="hidden" id="nomor_doang" value="1">
@stop